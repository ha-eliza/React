import "./App.css";
import Header from '../header/Header';
import Footer from '../footer/Footer';
import Ruby from "../card/ruby.png";
import AlterEgo from "../card/alter_ego.png";
import Billie from "../card/billie.png";
import Lana from "../card/lana.png";
import Card from "../card/Card";

function App() {
  return (
    <div className="App">
      <Header />
      <div className="main">
        <div className="container">
          <div style={{display: "flex", flexWrap: "wrap", gap: "20px", justifyContent: "center"}}>
            <Card image={Ruby} title="Ruby" artist="Jennie" year="07.03.2025" />
            <Card image={Billie} title="Hit Me Hard and Soft" artist="Billie Eilish" year="17.05.2024" />
            <Card image={Lana} title="Born to Die" artist="Lana Del Ray" year="27.02.2012" />
            <Card
              image={AlterEgo}
              title="Alter Ego"
              artist="Lisa"
              year="28.02.2025"
            />
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
}

export default App;
