function Footer() {
  return (
    <div
      style={{
        borderTop: "1px solid #ccc",
        padding: "5px 0",
        textAlign: "center",
      }}
    >
      Copyright
    </div>
  );
}
export default Footer;
