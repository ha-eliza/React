function Card(props) {
  let {image, title, artist, year} = props;
  return <div
    style={{
      border: "1px solid #8e8e8e",
      padding: "20px",
      borderRadius: "10px",
      width: "300px",
      minHeight: "450px",
      boxSizing: "border-box",
    }}
  >
    <img src={image} alt={title} style={{ width: "100%", objectFit: "cover", }} />
    <h2>{title}</h2>
    <p>Исполнитель: {artist}</p>
    <p>Год выпуска: {year}</p>
  </div>;
}
export default Card;
