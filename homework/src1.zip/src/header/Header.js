function Header() {
  return (
    <div
      style={{
        backgroundColor: "#bd0303",
        padding: "5px 20px",
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
      }}
    >
      <h2 style={{ textTransform: "uppercase", fontSize: "14px" }}>music</h2>
      <p style={{ fontSize: "14px" }}>Альбомы</p>
    </div>
  );
}
export default Header;
